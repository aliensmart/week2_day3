from app.animal import Dog, Cow, Tiger, Zoo
